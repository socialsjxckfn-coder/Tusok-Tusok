/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Menu } from './components/Menu';
import { About } from './components/About';
import { Reservations } from './components/Reservations';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="font-sans text-charcoal antialiased">
        <a
            href="#main-content"
            className="fixed left-4 top-4 z-[100] -translate-y-24 rounded-lg bg-gold px-5 py-3 font-bold text-charcoal shadow-lg transition-transform focus:translate-y-0 focus:outline-none focus:ring-4 focus:ring-white"
        >
            Skip to main content
        </a>
        
        <Navbar />
        
        <main id="main-content">
            <Hero />
            <Menu />
            <About />
            <Reservations />
            <Contact />
        </main>
        
        <Footer />
    </div>
  );
}
