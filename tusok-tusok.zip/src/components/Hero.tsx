import { ArrowRight, Check } from 'lucide-react';

export function Hero() {
    return (
        <section
            id="home"
            className="relative flex min-h-screen items-center overflow-hidden bg-charcoal pt-20 text-white"
            aria-labelledby="hero-heading"
        >
            <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: "url('https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=2000&q=85')" }}
                role="img"
                aria-label="A vibrant restaurant dining room with warm lighting"
            ></div>

            <div className="hero-overlay absolute inset-0"></div>

            <div className="absolute -right-28 top-24 h-80 w-80 rounded-full bg-crimson/30 blur-3xl" aria-hidden="true"></div>
            <div className="absolute -bottom-32 left-1/3 h-96 w-96 rounded-full bg-gold/20 blur-3xl" aria-hidden="true"></div>

            <div className="relative mx-auto grid w-full max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-12 lg:px-8">
                <div className="lg:col-span-8">
                    <div className="mb-6 inline-flex items-center gap-3 rounded-full border border-gold/50 bg-charcoal/60 px-4 py-2 backdrop-blur-md">
                        <span className="relative flex h-3 w-3" aria-hidden="true">
                            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-leaf opacity-75"></span>
                            <span className="relative inline-flex h-3 w-3 rounded-full bg-leaf"></span>
                        </span>
                        <span className="text-xs font-extrabold uppercase tracking-[0.20em] text-cream sm:text-sm">
                            Montreal’s Filipino Street-Food Spot
                        </span>
                    </div>

                    <h1 id="hero-heading" className="max-w-5xl font-display text-6xl leading-[0.88] tracking-wide text-white sm:text-7xl md:text-8xl lg:text-9xl">
                        Big Filipino <span className="text-gold">Flavor.</span>
                        <br />
                        Street-Side <span className="text-crimson">Energy.</span>
                    </h1>

                    <p className="mt-7 max-w-2xl text-lg leading-8 text-cream/90 sm:text-xl">
                        Experience authentic Filipino street-food favorites, bold family recipes, and the lively spirit of a Manila night market—right here in Montreal.
                    </p>

                    <div className="mt-9 flex flex-col gap-4 sm:flex-row">
                        <a href="#menu" className="animate-pulse-glow inline-flex min-h-14 items-center justify-center gap-2 rounded-full bg-gold px-8 py-4 text-base font-extrabold text-charcoal transition-all duration-[250ms] hover:scale-105 hover:brightness-110 focus:outline-none focus:ring-4 focus:ring-white/70">
                            View Menu
                            <ArrowRight className="h-5 w-5" aria-hidden="true" />
                        </a>
                        <a href="#reservations" className="svg-border-btn group relative inline-flex min-h-14 items-center justify-center rounded-full px-8 py-4 text-base font-extrabold text-white transition-all hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-gold/60">
                            <svg className="absolute inset-0 h-full w-full pointer-events-none overflow-visible" xmlns="http://www.w3.org/2000/svg">
                                <rect width="100%" height="100%" rx="28" fill="none" stroke="currentColor" strokeWidth="2" className="text-white transition-opacity duration-300 group-hover:opacity-20" />
                                <rect className="border-trace-active" width="100%" height="100%" rx="28" fill="none" stroke="var(--color-gold)" strokeWidth="2" pathLength="1" />
                            </svg>
                            <span className="relative z-10 group-hover:text-gold transition-colors duration-300">Reserve Table</span>
                        </a>
                    </div>

                    <div className="mt-10 flex flex-wrap gap-x-8 gap-y-4 text-sm font-semibold text-cream/85">
                        <span className="inline-flex items-center gap-2">
                            <Check className="h-5 w-5 text-gold" aria-hidden="true" /> Freshly prepared
                        </span>
                        <span className="inline-flex items-center gap-2">
                            <Check className="h-5 w-5 text-gold" aria-hidden="true" /> Family-inspired recipes
                        </span>
                        <span className="inline-flex items-center gap-2">
                            <Check className="h-5 w-5 text-gold" aria-hidden="true" /> Vegetarian options
                        </span>
                    </div>
                </div>

                <aside className="hidden lg:col-span-4 lg:block" aria-label="Featured menu item">
                    <div className="floating-card ml-auto max-w-sm rotate-2 rounded-[2rem] border border-white/20 bg-cream p-4 text-charcoal shadow-2xl">
                        <div className="relative overflow-hidden rounded-[1.5rem]">
                            <img
                                src="https://images.unsplash.com/photo-1626804475297-41608ea09aeb?auto=format&fit=crop&w=900&q=85"
                                alt="Colorful Filipino-inspired street-food platter"
                                className="h-72 w-full object-cover"
                                loading="eager"
                            />
                            <span className="absolute left-4 top-4 rounded-full bg-crimson px-4 py-2 text-xs font-extrabold uppercase tracking-wider text-white">
                                Crowd Favorite
                            </span>
                        </div>
                        <div className="p-4">
                            <div className="flex items-start justify-between gap-4">
                                <div>
                                    <p className="font-display text-3xl tracking-wide">Tusok Platter</p>
                                    <p className="mt-1 text-sm leading-6 text-charcoal/70">
                                        A shareable mix of kwek-kwek, fish balls, lumpia, and house-made dipping sauces.
                                    </p>
                                </div>
                                <span className="rounded-full bg-gold px-3 py-2 font-extrabold">$24</span>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>

            <a href="#menu" className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 rounded-md text-xs font-bold uppercase tracking-[0.25em] text-white/75 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/50 md:flex" aria-label="Scroll to menu">
                Explore
                <svg className="h-6 w-6 animate-bounce" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="m6 9 6 6 6-6" />
                </svg>
            </a>
        </section>
    );
}
