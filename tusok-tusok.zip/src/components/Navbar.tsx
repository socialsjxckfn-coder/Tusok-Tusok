import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export function Navbar() {
    const [isOpen, setIsOpen] = useState(false);

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth >= 1024) {
                setIsOpen(false);
            }
        };

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const toggleMenu = () => {
        setIsOpen(!isOpen);
    };

    const closeMenu = () => {
        setIsOpen(false);
    };

    return (
        <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-charcoal/95 text-white shadow-lg backdrop-blur-md">
            <nav className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8" aria-label="Main navigation">
                <a href="#home" className="group inline-flex items-center gap-3 rounded-md focus:outline-none focus:ring-4 focus:ring-gold/50" aria-label="Tusok-Tusok home">
                    <span className="flex h-11 w-11 items-center justify-center rounded-full bg-crimson font-display text-2xl tracking-wide text-white shadow-md transition-transform group-hover:rotate-6" aria-hidden="true">
                        TT
                    </span>
                    <span>
                        <span className="block font-display text-3xl leading-none tracking-wider text-gold">
                            Tusok-Tusok
                        </span>
                        <span className="hidden text-[0.65rem] font-bold uppercase tracking-[0.22em] text-white/70 sm:block">
                            Filipino Street Eats
                        </span>
                    </span>
                </a>

                {/* Desktop Navigation */}
                <div className="hidden items-center gap-1 lg:flex">
                    <a href="#home" className="rounded-lg px-4 py-3 text-sm font-semibold transition-colors hover:bg-white/10 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/40">
                        Home
                    </a>
                    <a href="#menu" className="rounded-lg px-4 py-3 text-sm font-semibold transition-colors hover:bg-white/10 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/40">
                        Menu
                    </a>
                    <a href="#about" className="rounded-lg px-4 py-3 text-sm font-semibold transition-colors hover:bg-white/10 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/40">
                        About
                    </a>
                    <a href="#contact" className="rounded-lg px-4 py-3 text-sm font-semibold transition-colors hover:bg-white/10 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/40">
                        Contact
                    </a>
                    <a href="#reservations" className="ml-3 rounded-full bg-gold px-6 py-3 text-sm font-extrabold text-charcoal shadow-glow transition-all hover:-translate-y-0.5 hover:bg-white focus:outline-none focus:ring-4 focus:ring-white/70">
                        Book a Table
                    </a>
                </div>

                {/* Mobile Menu Button */}
                <button
                    type="button"
                    className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-white/20 text-white transition-colors hover:bg-white/10 focus:outline-none focus:ring-4 focus:ring-gold/50 lg:hidden"
                    aria-controls="mobile-menu"
                    aria-expanded={isOpen}
                    aria-label={isOpen ? "Close navigation menu" : "Open navigation menu"}
                    onClick={toggleMenu}
                >
                    {isOpen ? <X className="h-6 w-6" aria-hidden="true" /> : <Menu className="h-6 w-6" aria-hidden="true" />}
                </button>
            </nav>

            {/* Mobile Navigation */}
            <div id="mobile-menu" className={`${isOpen ? 'block' : 'hidden'} border-t border-white/10 bg-charcoal px-4 pb-6 pt-3 lg:hidden`}>
                <div className="mx-auto flex max-w-7xl flex-col gap-1">
                    <a href="#home" onClick={closeMenu} className="rounded-lg px-4 py-3 font-semibold hover:bg-white/10 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/40">
                        Home
                    </a>
                    <a href="#menu" onClick={closeMenu} className="rounded-lg px-4 py-3 font-semibold hover:bg-white/10 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/40">
                        Menu
                    </a>
                    <a href="#about" onClick={closeMenu} className="rounded-lg px-4 py-3 font-semibold hover:bg-white/10 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/40">
                        About
                    </a>
                    <a href="#contact" onClick={closeMenu} className="rounded-lg px-4 py-3 font-semibold hover:bg-white/10 hover:text-gold focus:outline-none focus:ring-4 focus:ring-gold/40">
                        Contact
                    </a>
                    <a href="#reservations" onClick={closeMenu} className="mt-3 rounded-full bg-gold px-6 py-3 text-center font-extrabold text-charcoal hover:bg-white focus:outline-none focus:ring-4 focus:ring-white/70">
                        Book a Table
                    </a>
                </div>
            </div>
        </header>
    );
}
