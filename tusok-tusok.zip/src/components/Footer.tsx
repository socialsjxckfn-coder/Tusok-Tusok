import { Instagram, Facebook, Video } from 'lucide-react'; // Using Video as a placeholder for TikTok, or just generic vectors

export function Footer() {
    return (
        <footer className="bg-charcoal py-10 text-white">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col items-center justify-between gap-8 border-b border-white/10 pb-8 md:flex-row">
                    <a
                        href="#home"
                        className="rounded-md focus:outline-none focus:ring-4 focus:ring-gold/50"
                        aria-label="Return to the top of the Tusok-Tusok website"
                    >
                        <span className="font-display text-4xl tracking-wider text-gold">
                            Tusok-Tusok
                        </span>
                        <span className="block text-xs font-bold uppercase tracking-[0.22em] text-white/55">
                            Filipino Street Eats
                        </span>
                    </a>

                    <div className="flex items-center gap-3">
                        <a
                            href="#"
                            className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 text-white transition-all hover:-translate-y-1 hover:border-gold hover:bg-gold hover:text-charcoal focus:outline-none focus:ring-4 focus:ring-gold/50"
                            aria-label="Visit Tusok-Tusok on Instagram"
                        >
                            <Instagram className="h-5 w-5" />
                        </a>
                        <a
                            href="#"
                            className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 text-white transition-all hover:-translate-y-1 hover:border-gold hover:bg-gold hover:text-charcoal focus:outline-none focus:ring-4 focus:ring-gold/50"
                            aria-label="Visit Tusok-Tusok on Facebook"
                        >
                            <Facebook className="h-5 w-5" />
                        </a>
                        <a
                            href="#"
                            className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 text-white transition-all hover:-translate-y-1 hover:border-gold hover:bg-gold hover:text-charcoal focus:outline-none focus:ring-4 focus:ring-gold/50"
                            aria-label="Visit Tusok-Tusok on TikTok"
                        >
                            <Video className="h-5 w-5" />
                        </a>
                    </div>
                </div>

                <div className="flex flex-col items-center justify-between gap-5 pt-7 text-center text-sm text-white/55 sm:flex-row sm:text-left">
                    <p>
                        &copy; <span id="copyright-year">{new Date().getFullYear()}</span> Tusok-Tusok. All rights reserved.
                    </p>

                    <div className="flex flex-wrap justify-center gap-x-6 gap-y-3">
                        <a
                            href="#"
                            className="rounded underline-offset-4 hover:text-gold hover:underline focus:outline-none focus:ring-4 focus:ring-gold/40"
                        >
                            Privacy Policy
                        </a>
                        <a
                            href="#"
                            className="rounded underline-offset-4 hover:text-gold hover:underline focus:outline-none focus:ring-4 focus:ring-gold/40"
                        >
                            Terms
                        </a>
                    </div>
                </div>
            </div>
        </footer>
    );
}
