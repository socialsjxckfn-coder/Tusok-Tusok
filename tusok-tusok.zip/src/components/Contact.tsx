import { MapPin, Phone, Clock, ExternalLink } from 'lucide-react';

export function Contact() {
    return (
        <section
            id="contact"
            className="bg-cream py-20 sm:py-24"
            aria-labelledby="contact-heading"
        >
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="mx-auto max-w-3xl text-center">
                    <p className="text-sm font-extrabold uppercase tracking-[0.24em] text-crimson">
                        Visit Us
                    </p>
                    <h2 id="contact-heading" className="mt-3 font-display text-5xl tracking-wide sm:text-6xl">
                        Find Your New Favorite Spot
                    </h2>
                    <p className="mt-5 text-lg leading-8 text-charcoal/70">
                        Come for the street food, stay for the music, color, and warm Filipino hospitality.
                    </p>
                </div>

                <div className="mt-12 grid overflow-hidden rounded-[2rem] bg-white shadow-card lg:grid-cols-2">
                    <div className="p-8 sm:p-10 lg:p-12">
                        <h3 className="font-display text-4xl tracking-wide text-charcoal">
                            Tusok-Tusok Montreal
                        </h3>

                        <div className="mt-8 space-y-7">
                            <div className="flex items-start gap-4">
                                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold text-charcoal" aria-hidden="true">
                                    <MapPin className="h-6 w-6" />
                                </span>
                                <div>
                                    <h4 className="font-bold text-charcoal">Address</h4>
                                    <address className="mt-1 not-italic leading-7 text-charcoal/70">
                                        6225 Av. Victoria<br />
                                        Montréal, QC H3W 1H2
                                    </address>
                                </div>
                            </div>

                            <div className="flex items-start gap-4">
                                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold text-charcoal" aria-hidden="true">
                                    <Phone className="h-6 w-6" />
                                </span>
                                <div>
                                    <h4 className="font-bold text-charcoal">Phone</h4>
                                    <a
                                        href="tel:+15147399898"
                                        className="mt-1 inline-block rounded text-charcoal/70 underline decoration-gold decoration-2 underline-offset-4 hover:text-crimson focus:outline-none focus:ring-4 focus:ring-gold/40"
                                    >
                                        (514) 739-9898
                                    </a>
                                </div>
                            </div>

                            <div className="flex items-start gap-4">
                                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold text-charcoal" aria-hidden="true">
                                    <Clock className="h-6 w-6" />
                                </span>
                                <div className="w-full">
                                    <h4 className="font-bold text-charcoal">
                                        Hours of Operation
                                    </h4>
                                    <dl className="mt-3 space-y-2 text-sm text-charcoal/70">
                                        <div className="flex justify-between gap-4 border-b border-charcoal/10 pb-2">
                                            <dt>Monday</dt>
                                            <dd className="font-semibold">Closed</dd>
                                        </div>
                                        <div className="flex justify-between gap-4 border-b border-charcoal/10 pb-2">
                                            <dt>Tuesday–Saturday</dt>
                                            <dd className="text-right font-semibold">
                                                2:00 PM–11:00 PM
                                            </dd>
                                        </div>
                                        <div className="flex justify-between gap-4">
                                            <dt>Sunday</dt>
                                            <dd className="text-right font-semibold">
                                                11:00 AM–9:00 PM
                                            </dd>
                                        </div>
                                    </dl>
                                </div>
                            </div>
                        </div>

                        <a
                            href="https://www.google.com/maps/search/?api=1&query=6225+Av.+Victoria,+Montreal,+QC+H3W+1H2"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-9 inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-charcoal px-6 py-3 font-bold text-white transition-all hover:-translate-y-1 hover:bg-crimson focus:outline-none focus:ring-4 focus:ring-crimson/30"
                        >
                            Get Directions
                            <ExternalLink className="h-5 w-5" />
                        </a>
                    </div>

                    <div className="relative min-h-[30rem] bg-charcoal">
                        <iframe
                            title="Map showing the location of Tusok-Tusok in Montreal"
                            src="https://www.google.com/maps?q=6225+Av.+Victoria,+Montreal,+QC+H3W+1H2&output=embed"
                            className="absolute inset-0 h-full w-full border-0"
                            loading="lazy"
                            referrerPolicy="no-referrer-when-downgrade"
                            allowFullScreen
                        ></iframe>
                    </div>
                </div>
            </div>
        </section>
    );
}
