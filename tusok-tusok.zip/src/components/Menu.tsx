import { useState } from 'react';

const appetizers = [
    {
        title: "Lumpiang Shanghai",
        description: "Crispy Filipino spring rolls filled with seasoned pork, vegetables, and aromatics, served with sweet chili sauce.",
        price: "$10",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Contains Gluten", type: "crimson" }]
    },
    {
        title: "Kwek-Kwek",
        description: "Quail eggs coated in our signature orange batter, fried until crisp, and paired with spiced vinegar.",
        price: "$9",
        image: "https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Vegetarian", type: "gold" }, { text: "Contains Egg", type: "crimson" }]
    },
    {
        title: "Isaw Skewers",
        description: "Char-grilled Filipino-style chicken skewers glazed with sweet soy barbecue sauce and served with chili vinegar.",
        price: "$12",
        image: "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Gluten-Free Option", type: "leaf" }]
    }
];

const mains = [
    {
        title: "Chicken Inasal",
        description: "Annatto-marinated grilled chicken with garlic rice, pickled papaya, calamansi, and house chicken oil.",
        price: "$19",
        image: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Gluten-Free Option", type: "leaf" }]
    },
    {
        title: "Sizzling Sisig",
        description: "Crispy chopped pork with onions, chilies, calamansi, creamy sauce, and a sunny-side egg on a hot plate.",
        price: "$21",
        image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Contains Egg", type: "crimson" }, { text: "Spicy", type: "warmOrange" }]
    },
    {
        title: "Pancit Canton",
        description: "Stir-fried noodles with vegetables, citrus, garlic, and your choice of chicken, shrimp, or tofu.",
        price: "$17",
        image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Vegan Option", type: "leaf" }, { text: "Contains Gluten", type: "crimson" }]
    }
];

const desserts = [
    {
        title: "Halo-Halo",
        description: "Shaved ice layered with tropical fruit, sweet beans, jellies, coconut, leche flan, and ube ice cream.",
        price: "$12",
        image: "https://images.unsplash.com/photo-1560008581-09826d1de69e?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Vegetarian", type: "gold" }, { text: "Contains Dairy", type: "crimson" }]
    },
    {
        title: "Turon",
        description: "Crispy caramelized banana and jackfruit rolls with brown-sugar glaze and optional ube ice cream.",
        price: "$9",
        image: "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Vegan Option", type: "leaf" }, { text: "Contains Gluten", type: "crimson" }]
    },
    {
        title: "Ube Leche Flan",
        description: "Silky caramel custard layered with creamy purple-yam halaya and toasted coconut.",
        price: "$11",
        image: "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Vegetarian", type: "gold" }, { text: "Contains Egg & Dairy", type: "crimson" }]
    }
];

const drinks = [
    {
        title: "Calamansi Fizz",
        description: "Fresh calamansi juice, sparkling water, cane sugar, and citrus peel served over ice.",
        price: "$6",
        image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Vegan", type: "leaf" }, { text: "Gluten-Free", type: "leaf" }]
    },
    {
        title: "Sago’t Gulaman",
        description: "A chilled Filipino classic with brown-sugar syrup, tapioca pearls, pandan jelly, and crushed ice.",
        price: "$7",
        image: "https://images.unsplash.com/photo-1558857563-b371033873b8?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Vegan", type: "leaf" }, { text: "Gluten-Free", type: "leaf" }]
    },
    {
        title: "Iced Ube Latte",
        description: "Creamy ube, espresso, milk, vanilla, and a touch of sea salt poured over ice.",
        price: "$7",
        image: "https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=900&q=85",
        tags: [{ text: "Dairy-Free Option", type: "leaf" }]
    }
];

function MenuItem({ item }: { item: any }) {
    return (
        <article className="group overflow-hidden rounded-[1.75rem] bg-white shadow-card transition-all hover:-translate-y-2 hover:shadow-2xl">
            <div className="relative overflow-hidden">
                <img
                    src={item.image}
                    alt={item.title}
                    className="h-56 w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                />
                <span className="absolute right-4 top-4 rounded-full bg-charcoal px-4 py-2 font-extrabold text-gold">
                    {item.price}
                </span>
            </div>
            <div className="p-6">
                <h3 className="font-display text-3xl tracking-wide">{item.title}</h3>
                <p className="mt-2 min-h-16 text-sm leading-6 text-charcoal/70">
                    {item.description}
                </p>
                <div className="mt-5 flex flex-wrap gap-2">
                    {item.tags.map((tag: any, index: number) => {
                        let tagClasses = "rounded-full px-3 py-1 text-xs font-bold ";
                        if (tag.type === "crimson") {
                            tagClasses += "bg-crimson/10 text-crimson";
                        } else if (tag.type === "gold") {
                            tagClasses += "bg-gold/25 text-charcoal";
                        } else if (tag.type === "leaf") {
                            tagClasses += "bg-leaf/15 text-leaf";
                        } else if (tag.type === "warmOrange") {
                            tagClasses += "bg-warmOrange/15 text-warmOrange";
                        }

                        return (
                            <span key={index} className={tagClasses}>
                                {tag.text}
                            </span>
                        );
                    })}
                </div>
            </div>
        </article>
    );
}

export function Menu() {
    const [activeTab, setActiveTab] = useState('appetizers');

    const tabs = [
        { id: 'appetizers', label: 'Appetizers' },
        { id: 'mains', label: 'Mains' },
        { id: 'desserts', label: 'Desserts' },
        { id: 'drinks', label: 'Drinks' },
    ];

    const getPanelData = () => {
        switch (activeTab) {
            case 'appetizers': return appetizers;
            case 'mains': return mains;
            case 'desserts': return desserts;
            case 'drinks': return drinks;
            default: return [];
        }
    };

    return (
        <section id="menu" className="street-pattern bg-cream py-20 sm:py-24" aria-labelledby="menu-heading">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="mx-auto max-w-3xl text-center">
                    <p className="text-sm font-extrabold uppercase tracking-[0.24em] text-crimson">
                        Sarap Starts Here
                    </p>
                    <h2 id="menu-heading" className="mt-3 font-display text-5xl tracking-wide text-charcoal sm:text-6xl">
                        Street-Food Favorites
                    </h2>
                    <p className="mt-5 text-base leading-8 text-charcoal/70 sm:text-lg">
                        Familiar Filipino comfort food, nostalgic street-market snacks, and playful modern twists prepared for sharing.
                    </p>
                </div>

                <div className="mt-12 rounded-[2rem] bg-charcoal p-3 shadow-card">
                    <div className="grid grid-cols-2 gap-2 md:grid-cols-4" role="tablist" aria-label="Food menu categories">
                        {tabs.map((tab) => (
                            <button
                                key={tab.id}
                                type="button"
                                className="menu-tab min-h-12 rounded-2xl px-5 py-3 text-sm font-extrabold transition-all focus:outline-none focus:ring-4 focus:ring-gold/60"
                                role="tab"
                                aria-selected={activeTab === tab.id}
                                aria-controls={`panel-${tab.id}`}
                                tabIndex={activeTab === tab.id ? 0 : -1}
                                onClick={() => setActiveTab(tab.id)}
                            >
                                {tab.label}
                            </button>
                        ))}
                    </div>
                </div>

                <div
                    id={`panel-${activeTab}`}
                    className="menu-panel mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3"
                    role="tabpanel"
                    aria-labelledby={`tab-${activeTab}`}
                    tabIndex={0}
                >
                    {getPanelData().map((item, index) => (
                        <MenuItem key={index} item={item} />
                    ))}
                </div>

                <p className="mt-10 text-center text-sm leading-6 text-charcoal/65">
                    Please inform our team about allergies before ordering. Cross-contact may occur in our kitchen.
                </p>
            </div>
        </section>
    );
}
