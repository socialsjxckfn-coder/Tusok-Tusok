import { useState } from 'react';
import { Calendar, Clock, ArrowRight } from 'lucide-react';

export function Reservations() {
    const [status, setStatus] = useState<{ message: string, type: 'error' | 'success' } | null>(null);

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        
        const form = e.currentTarget;
        if (!form.checkValidity()) {
            form.reportValidity();
            setStatus({
                message: "Please complete all required fields with valid information.",
                type: 'error'
            });
            return;
        }

        const formData = new FormData(form);
        const guestName = formData.get("fullName");
        const selectedDate = formData.get("date") as string;
        const selectedTime = formData.get("time") as string;

        const formattedDate = new Intl.DateTimeFormat("en-CA", {
            year: "numeric",
            month: "long",
            day: "numeric"
        }).format(new Date(`${selectedDate}T12:00:00`));

        const formattedTime = new Intl.DateTimeFormat("en-CA", {
            hour: "numeric",
            minute: "2-digit"
        }).format(new Date(`2000-01-01T${selectedTime}:00`));

        setStatus({
            message: `Thank you, ${guestName}! Your reservation request for ${formattedDate} at ${formattedTime} has been received. Our team will contact you to confirm.`,
            type: 'success'
        });

        form.reset();
    };

    const today = new Date();
    const timezoneOffset = today.getTimezoneOffset() * 60000;
    const localDate = new Date(today.getTime() - timezoneOffset).toISOString().split("T")[0];

    return (
        <section
            id="reservations"
            className="relative overflow-hidden bg-crimson py-20 sm:py-24"
            aria-labelledby="reservation-heading"
        >
            <div className="absolute -left-24 top-10 h-80 w-80 rounded-full bg-gold/25 blur-3xl" aria-hidden="true"></div>
            <div className="absolute -bottom-32 right-0 h-96 w-96 rounded-full bg-warmOrange/25 blur-3xl" aria-hidden="true"></div>

            <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
                <div className="grid overflow-hidden rounded-[2rem] bg-cream shadow-2xl lg:grid-cols-5">
                    <div className="bg-charcoal p-8 text-white sm:p-10 lg:col-span-2 lg:p-12">
                        <p className="text-sm font-extrabold uppercase tracking-[0.24em] text-gold">
                            Save Your Spot
                        </p>
                        <h2 id="reservation-heading" className="mt-3 font-display text-5xl leading-none tracking-wide sm:text-6xl">
                            Reserve Your Table
                        </h2>
                        <p className="mt-6 leading-8 text-white/70">
                            Planning a date night, family meal, or barkada reunion? Reserve ahead and we’ll have your table ready.
                        </p>

                        <div className="mt-9 space-y-6">
                            <div className="flex gap-4">
                                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gold text-charcoal" aria-hidden="true">
                                    <Calendar className="h-5 w-5" />
                                </span>
                                <div>
                                    <h3 className="font-bold text-gold">Easy Booking</h3>
                                    <p className="mt-1 text-sm leading-6 text-white/65">
                                        Select your preferred date, time, and party size in just a few steps.
                                    </p>
                                </div>
                            </div>
                            <div className="flex gap-4">
                                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gold text-charcoal" aria-hidden="true">
                                    <Clock className="h-5 w-5" />
                                </span>
                                <div>
                                    <h3 className="font-bold text-gold">Confirmation</h3>
                                    <p className="mt-1 text-sm leading-6 text-white/65">
                                        Our team will contact you to confirm your reservation details.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="mt-10 rounded-2xl border border-white/10 bg-white/5 p-5">
                            <p className="text-sm leading-6 text-white/70">
                                For parties of eight or more, please call us directly so we can arrange the best experience.
                            </p>
                        </div>
                    </div>

                    <div className="p-8 sm:p-10 lg:col-span-3 lg:p-12">
                        <form id="reservation-form" noValidate onSubmit={handleSubmit}>
                            <div className="grid gap-6 sm:grid-cols-2">
                                <div className="sm:col-span-2">
                                    <label htmlFor="full-name" className="mb-2 block text-sm font-bold text-charcoal">
                                        Full Name <span className="text-crimson" aria-hidden="true">*</span>
                                    </label>
                                    <input
                                        id="full-name"
                                        name="fullName"
                                        type="text"
                                        autoComplete="name"
                                        required
                                        minLength={2}
                                        placeholder="Juan Dela Cruz"
                                        className="min-h-12 w-full rounded-xl border-2 border-charcoal/15 bg-white px-4 py-3 text-charcoal placeholder:text-charcoal/40 transition-colors focus:border-crimson focus:outline-none focus:ring-4 focus:ring-crimson/15"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="email" className="mb-2 block text-sm font-bold text-charcoal">
                                        Email Address <span className="text-crimson" aria-hidden="true">*</span>
                                    </label>
                                    <input
                                        id="email"
                                        name="email"
                                        type="email"
                                        autoComplete="email"
                                        required
                                        placeholder="juan@example.com"
                                        className="min-h-12 w-full rounded-xl border-2 border-charcoal/15 bg-white px-4 py-3 text-charcoal placeholder:text-charcoal/40 transition-colors focus:border-crimson focus:outline-none focus:ring-4 focus:ring-crimson/15"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="phone" className="mb-2 block text-sm font-bold text-charcoal">
                                        Phone Number <span className="text-crimson" aria-hidden="true">*</span>
                                    </label>
                                    <input
                                        id="phone"
                                        name="phone"
                                        type="tel"
                                        autoComplete="tel"
                                        required
                                        placeholder="514-555-1234"
                                        className="min-h-12 w-full rounded-xl border-2 border-charcoal/15 bg-white px-4 py-3 text-charcoal placeholder:text-charcoal/40 transition-colors focus:border-crimson focus:outline-none focus:ring-4 focus:ring-crimson/15"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="reservation-date" className="mb-2 block text-sm font-bold text-charcoal">
                                        Date <span className="text-crimson" aria-hidden="true">*</span>
                                    </label>
                                    <input
                                        id="reservation-date"
                                        name="date"
                                        type="date"
                                        required
                                        min={localDate}
                                        className="min-h-12 w-full rounded-xl border-2 border-charcoal/15 bg-white px-4 py-3 text-charcoal transition-colors focus:border-crimson focus:outline-none focus:ring-4 focus:ring-crimson/15"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="reservation-time" className="mb-2 block text-sm font-bold text-charcoal">
                                        Time <span className="text-crimson" aria-hidden="true">*</span>
                                    </label>
                                    <select
                                        id="reservation-time"
                                        name="time"
                                        required
                                        className="min-h-12 w-full rounded-xl border-2 border-charcoal/15 bg-white px-4 py-3 text-charcoal transition-colors focus:border-crimson focus:outline-none focus:ring-4 focus:ring-crimson/15"
                                    >
                                        <option value="">Select a time</option>
                                        <option value="11:30">11:30 AM</option>
                                        <option value="12:00">12:00 PM</option>
                                        <option value="12:30">12:30 PM</option>
                                        <option value="13:00">1:00 PM</option>
                                        <option value="17:00">5:00 PM</option>
                                        <option value="17:30">5:30 PM</option>
                                        <option value="18:00">6:00 PM</option>
                                        <option value="18:30">6:30 PM</option>
                                        <option value="19:00">7:00 PM</option>
                                        <option value="19:30">7:30 PM</option>
                                        <option value="20:00">8:00 PM</option>
                                        <option value="20:30">8:30 PM</option>
                                        <option value="21:00">9:00 PM</option>
                                    </select>
                                </div>
                                <div className="sm:col-span-2">
                                    <label htmlFor="party-size" className="mb-2 block text-sm font-bold text-charcoal">
                                        Party Size <span className="text-crimson" aria-hidden="true">*</span>
                                    </label>
                                    <select
                                        id="party-size"
                                        name="partySize"
                                        required
                                        className="min-h-12 w-full rounded-xl border-2 border-charcoal/15 bg-white px-4 py-3 text-charcoal transition-colors focus:border-crimson focus:outline-none focus:ring-4 focus:ring-crimson/15"
                                    >
                                        <option value="">Select party size</option>
                                        <option value="1">1 Guest</option>
                                        <option value="2">2 Guests</option>
                                        <option value="3">3 Guests</option>
                                        <option value="4">4 Guests</option>
                                        <option value="5">5 Guests</option>
                                        <option value="6">6 Guests</option>
                                        <option value="7">7 Guests</option>
                                        <option value="8">8 Guests</option>
                                    </select>
                                </div>
                            </div>

                            <p className="mt-5 text-sm text-charcoal/60">
                                Fields marked with an asterisk are required.
                            </p>

                            <button
                                type="submit"
                                className="group mt-7 inline-flex min-h-14 w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-crimson px-8 py-4 font-extrabold text-white shadow-lg transition-all hover:-translate-y-1 hover:bg-charcoal hover:shadow-2xl focus:outline-none focus:ring-4 focus:ring-crimson/30"
                            >
                                <span>Submit Reservation</span>
                                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                            </button>

                            {status && (
                                <div
                                    id="reservation-status"
                                    className={`mt-5 rounded-xl border p-4 text-sm font-semibold ${
                                        status.type === 'error' ? 'border-crimson bg-crimson/10 text-crimson' : 'border-leaf bg-leaf/10 text-leaf'
                                    }`}
                                    role="status"
                                    aria-live="polite"
                                >
                                    {status.message}
                                </div>
                            )}
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}
