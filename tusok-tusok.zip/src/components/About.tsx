export function About() {
    return (
        <section
            id="about"
            className="overflow-hidden bg-charcoal py-20 text-white sm:py-24"
            aria-labelledby="about-heading"
        >
            <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:gap-20 lg:px-8">
                <div className="relative">
                    <div className="absolute -left-6 -top-6 h-28 w-28 rounded-full border-[14px] border-gold/25" aria-hidden="true"></div>

                    <div className="relative overflow-hidden rounded-[2rem] shadow-2xl">
                        <img
                            src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1400&q=85"
                            alt="Warm, colorful restaurant interior with communal tables"
                            className="h-[34rem] w-full object-cover"
                            loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-charcoal/65 via-transparent to-transparent"></div>
                        <div className="absolute bottom-5 left-5 right-5 rounded-2xl border border-white/20 bg-charcoal/75 p-5 backdrop-blur-md">
                            <p className="font-display text-3xl tracking-wide text-gold">
                                Kain Tayo!
                            </p>
                            <p className="mt-1 text-sm text-white/85">
                                “Let’s eat”—because the best Filipino meals are always shared.
                            </p>
                        </div>
                    </div>

                    <div className="absolute -bottom-7 -right-2 rounded-2xl bg-crimson p-6 text-white shadow-2xl sm:right-7">
                        <p className="font-display text-4xl tracking-wide">100%</p>
                        <p className="text-xs font-extrabold uppercase tracking-widest">
                            Filipino Heart
                        </p>
                    </div>
                </div>

                <div>
                    <p className="text-sm font-extrabold uppercase tracking-[0.24em] text-gold">
                        Our Story
                    </p>
                    <h2 id="about-heading" className="mt-3 font-display text-5xl leading-none tracking-wide sm:text-6xl">
                        From Manila’s Streets <span className="text-gold">to Montreal.</span>
                    </h2>
                    <p className="mt-7 text-lg leading-8 text-cream/85">
                        Tusok-Tusok was created to bring the excitement, flavor, and togetherness of Filipino street markets to Montreal. Our name celebrates the joy of choosing your favorite skewered snacks, dipping them into bold sauces, and sharing the experience with friends.
                    </p>
                    <p className="mt-5 leading-8 text-cream/70">
                        We prepare our dishes with fresh ingredients, time-honored family recipes, and a modern approach that welcomes longtime Filipino-food lovers and first-time adventurous eaters alike. The result is a lively neighborhood restaurant where heritage feels current and every visit feels like a celebration.
                    </p>

                    <div className="mt-9 grid gap-5 sm:grid-cols-3">
                        <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                            <span className="text-3xl" aria-hidden="true">🌿</span>
                            <h3 className="mt-3 font-bold text-gold">Fresh Ingredients</h3>
                            <p className="mt-2 text-sm leading-6 text-white/65">
                                Prepared with care and vibrant seasonal produce.
                            </p>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                            <span className="text-3xl" aria-hidden="true">🔥</span>
                            <h3 className="mt-3 font-bold text-gold">Bold Flavors</h3>
                            <p className="mt-2 text-sm leading-6 text-white/65">
                                Smoky, sweet, sour, savory, and satisfyingly spicy.
                            </p>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                            <span className="text-3xl" aria-hidden="true">🤝</span>
                            <h3 className="mt-3 font-bold text-gold">Shared Culture</h3>
                            <p className="mt-2 text-sm leading-6 text-white/65">
                                A welcoming table built for food and community.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
